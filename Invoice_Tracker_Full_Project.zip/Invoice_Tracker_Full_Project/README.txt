INVOICE TRACKER - FULL UIPATH PROJECT

Structure:
1 - INITIALIZATION
2 - PROCESS
    - Workflows\Extract_Customer.xaml
    - Workflows\Calculate_Billing.xaml
3 - OUTPUT
    - Send Outlook Desktop email with completed Excel attached

Before running:
1. Put UiPath_Customer_Extraction_Source.pdf in the Input folder.
2. Open Main.xaml and set the recipient address in activity: Initialize - Email Recipient.
3. Outlook Desktop must be installed/configured for the Send Outlook Desktop Mail Message activity.
4. The completed Excel file is Output\UiPath_Invoice_Tracker_Template.xlsx and is attached to the email.
