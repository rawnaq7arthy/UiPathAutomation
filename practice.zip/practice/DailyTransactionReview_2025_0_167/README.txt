DAILY TRANSACTION REVIEW & RISK CLASSIFICATION BOT
Target Studio build: 2025.0.167 (May 29, 2025)
Project compatibility: Windows / Visual Basic

PINNED DEPENDENCIES
- UiPath.System.Activities 25.4.4
- UiPath.Excel.Activities 2.24.4

HOW TO OPEN
1. Extract the ZIP.
2. In UiPath Studio 2025.0.167, choose Open > Local Project.
3. Select project.json in this folder.
4. Allow Studio to restore the two pinned dependencies from the Official feed.
5. Run Main.xaml.

WHAT THE BOT DOES
- Checks that Data\UiPath_Foundation_Bank_Transaction_Review.xlsx exists.
- Reads Config and Transactions sheets.
- Calculates total transactions and total amount.
- Filters Amount >= MinimumReviewAmount.
- Sorts Amount descending.
- Adds RiskLevel and uses IF to classify High Value / Normal Review.
- Uses SWITCH for Completed / Pending / Failed / default statuses.
- Uses For Each Row to process filtered transactions.
- Writes summary statistics to B3:B6 and the filtered table from A9.
- Uses Try Catch and Log Message for exception handling and debugging.

EXPECTED RESULTS WITH THE PROVIDED SAMPLE DATA
- Total Transactions: 25
- Total Amount: 54,980.50 OMR
- High Value Transactions: 5
- Failed/Pending Transactions: 4
- Review rows (Amount >= 1,000): 10

IMPORTANT
The project uses the workbook inside the Data folder and writes the results back into that workbook's Summary sheet.
