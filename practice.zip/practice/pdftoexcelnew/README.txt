UiPath Invoice Processing - Revised for Studio 2025.0.167

FILES
- Main.xaml
- InitAllSettings.xaml
- Extract Customer Name.xaml
- Calculate Billing.xaml
- Data\Config.xlsx

EXPECTED INPUT FILES (not included in the uploaded files)
- Data\Input\UiPath_Customer_Extraction_Source.pdf
- Data\Input\Tamplate\excelFile1.xlsx

OUTPUT
- Data\Output\UiPath_Invoice_Tracker_Template.xlsx

IMPROVEMENTS
1. Main checks Config.xlsx exists AND is not a zero-byte file before loading configuration.
2. Main checks the source Excel template exists AND is not a zero-byte file before copying it.
3. Extract Customer Name checks the PDF exists AND is not empty.
4. Extract Customer Name checks the output Excel exists AND is not empty before opening it.
5. Required Invoice Register sheet is checked before writing the customer name.
6. Calculate Billing checks the Excel file exists AND is not empty.
7. Required Invoice Register and Billing Data sheets are checked before processing.
8. Billing Data is read first, then checked for rows/columns before filtering or averaging.
9. One Filter Data Table activity contains both filters with AND:
   - Current or Previous = Current
   - Billing Currency = USD
10. Average expressions return 0 when ISSR/ACQR/Both has no matching rows, preventing Average() on an empty sequence.
11. Sheet names and output cells are driven by Config where possible.
12. Missing/empty files and missing sheets log a clear error and throw an exception so the email stage is not reached with incomplete output.
13. Workflow filenames now exactly match the Invoke Workflow File references in Main.xaml.

IMPORTANT
The two real input files above were not included in the upload, so an end-to-end execution against the actual PDF/Excel data could not be performed here. The XAML files were checked for well-formed XML and internal filename/argument consistency, while retaining the activity families already used by your project to reduce package/version risk.
