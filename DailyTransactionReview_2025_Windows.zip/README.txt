UiPath Studio 2025 Windows project
Studio metadata: 25.10.0.0
Compatibility: Windows
Expression language: Visual Basic

IMPORTANT:
Open the folder itself in UiPath Studio (do not open a XAML directly).
If your installed Studio build is 25.0/25.4/25.10 rather than exactly 25.10,
Studio may update the project metadata/dependencies automatically on restore.

The supplied Excel workbook should be copied into Data/UiPath_Foundation_Bank_Transaction_Review.xlsx.
